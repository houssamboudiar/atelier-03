var r_links = document.querySelctorAll(".reserve")

for(var i=0; i<r_likns.lenght; i++){
	
	r_links[i].addEventListener("click", function(){
				
	}, false)
	
}


var agent_id = document.querySelctorAll("select")

for(var j=0; j<agent_id.lenght; j++){
	
	agent_id[j].addEventListener("change", function(){
				console.log(this)
	}, false)
	
}